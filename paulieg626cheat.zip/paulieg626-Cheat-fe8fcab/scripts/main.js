//Block
require("blocks/liquid");
require("blocks/power");
require("blocks/wall");
require("blocks/turret");
require("blocks/value");
//require("blocks/magic");
require("blocks/conv");
require("blocks/shield");
require("blocks/boost");
require("blocks/cc");
require("blocks/item");
require("blocks/skip");
//Block2
require("blocks/liquid2");
require("blocks/power2");
require("blocks/wall2");
require("blocks/turret2");
require("blocks/value2");
//require("blocks/magic2");
require("blocks/conv2");
require("blocks/shield2");
require("blocks/boost2");
require("blocks/cc2");
require("blocks/item2");
require("blocks/skip2");

print("$$$$$$$$$$$$$$$$$$$");
print("Mindustry CheatMod");
print("by paulieg626");
print("$$$$$$$$$$$$$$$$$$$");

var mod = Vars.mods.locateMod("cheat");
mod.meta.displayName = "[yellow]Cheat[orange]MOD";
mod.meta.description = "@mod.cheat.description";
mod.meta.author = "[brick]paulieg626";