# Exogenesis Units - Liberated
Easy access to Exogenesis units.

<br>

**IMPORTANT NOTICE:**

    This mod does NOT break the license specified and used by AureusStratus.

    The license from AureusStratus currently says: "Dont us my sprites without permission".

    This mod does NOT break that rule, because this mod contains NONE of those sprites.

    All the sprites belonging to AureusStratus live safely in their own mod, and only there.

<br>

**WARNING:**

This is effectively a cheat mod. This mod gives the player access to over-powered units and/or components. Don't use this mod, if you don't want the original game-play of the game spoiled for you!

<br>

**Notes:**

This mod basically gives you easy access to some of the units from the Exogenesis mod.

<br>

There is no need to research any of these units on the Tech Tree. They are all unlocked by default.

<br>

This mod provides 3 factory buildings, so that you can build (and use) the units. {No reconstructor blocks are necessary.}

<br>

This mod can be used in the campaign, to get an extra boost of units, which are stronger than the vanilla in-game units.

<br>

I made this small mod, because I wanted to play with the Exogenesis units, but I did not want to spend hours and days gathering and manufacturing all the required resources (items), in order to unlock all the components of Exogenesis on the Tech Tree.

<br>

This mod has the Exogenesis mod as a dependency.

<br>

I hope you enjoy this mod, and have fun with it.

<br>

The original ExoGenesis mod can be found here:
https://github.com/AureusStratus/ExoGenesis
