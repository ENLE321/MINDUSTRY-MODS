### Cheat [Mindusty 7.0 Mod] 
[![CheatMod Icon](https://raw.githubusercontent.com/paulieg626/Cheat/master/icon.png)]()

En:

`Download: paulieg626/Cheat`

- Fill the core up to 900kk items!!!

- Spawn units who you want!!!

Ru:

`Скачать: paulieg626/Cheat`

- Заполни ядро до 900кк предметов!!!

- Создавайте юнитов, которые хотите!!!

Url:

[Cheat on VKontakte](https://vk.com/mindustry_cheat)

[![Join our Discord server!](https://invidget.switchblade.xyz/UJyZWayvGH)](https://discord.gg/UJyZWayvGH)
