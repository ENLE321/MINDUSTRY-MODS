![icon](icon.png)

- Adds a bunch of stuff.
- Takes some inspiration from EyeOfDarkness/AdvanceContent
- Will be archived when the java port is finished
