![](https://github.com/Arth0x/AetherUnbound/blob/master/sprites/ui/front-cover.png)

<h1>Welcom to MindusTrinity<h1>

<h2>A little addon with 3 new element. This mod add turrets, new units and lots of vanilla improvement.<h2>

<h2>This is not a full release and might be bugged, unbalanced or not textured so keep it up to date.<h2>

<h2>If you are reading this you might be interested in my mod so here is the addon link of my mod that will unlock beta content for you :P<h2>

<h2>Arth0x/Trinity-Beta<h2>

<h3>#myfirstmod<h3>







