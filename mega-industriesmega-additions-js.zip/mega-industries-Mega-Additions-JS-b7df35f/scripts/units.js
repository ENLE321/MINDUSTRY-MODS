const assembler = extend(UnitFactory, "assembler", {});

