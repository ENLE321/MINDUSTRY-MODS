const crystalRefiningSite = new SectorPreset("crystal-refining-site", Planets.serpulo, 173);
crystalRefiningSite.captureWave = 10;
crystalRefiningSite.difficulty = 2;
