# Super-Cheat
Adds cheat blocks. 
